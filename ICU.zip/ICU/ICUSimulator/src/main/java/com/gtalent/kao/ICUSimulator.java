package com.gtalent.kao;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class ICUSimulator {
    private static final Logger log = LoggerFactory.getLogger(ICUSimulator.class);

    public static void main(String[] args) throws Exception {
        URI uri = new URI("ws://localhost:8080"); //WebSocket

        WebSocketClient wsc = new WebSocketClient(uri) {
            @Override
            public void onOpen(ServerHandshake serverHandshake) {
                System.out.println("Connected");
                new Timer().scheduleAtFixedRate(
                        () -> {
                            try {
                                Map<String, String> data = new HashMap<>();
                                data.put("nationalId", "001");
                                data.put("heartRate", String.valueOf(60 + new Random().nextInt(40)));
                                data.put("pulse", String.valueOf(50 + new Random().nextInt(10)));
                                data.put("timestamp", String.valueOf(LocalDateTime.now()));
                                data.put("ecg", generateECG().toString());

                                //Map 轉 JSON
                                String json = new ObjectMapper().writeValueAsString(data);
                                send(json);
                                System.out.println("Sent" + json);
                            } catch (Exception e) {
                                log.error("錯誤發生", e);
                            }
                        }
                        , 0, 1000);
            }


            @Override
            public void onMessage(String s) {
                System.out.println("Get message:" + s);
            }

            @Override
            public void onClose(int i, String s, boolean b) {
                System.out.println("Shutdown");
            }

            @Override
            public void onError(Exception e) {

            }

        };
        wsc.connect;
    }

    private static List<Double> generateECG() {
        List<Double> ecg = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            ecg.add(Math.sin(i * 0.1)+ ThreadLocalRandom.current().nextDouble(-0.05, 0.05));
        }
        return ecg;
    }

}