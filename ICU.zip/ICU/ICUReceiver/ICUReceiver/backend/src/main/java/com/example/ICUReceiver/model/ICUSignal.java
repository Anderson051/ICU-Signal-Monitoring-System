package com.example.ICUReceiver.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;


@Entity

public class ICUSignal {

    @Id
    @GeneratedValue
    private int id;

    private int nationalId
    private int heartRate;
    private int pulse;
    private LocalDateTime timestamp;

@ElementCollection
    private List<Double> ecg;

    public ICUSignal(int id, int nationalId, int heartRate, int pulse, LocalDateTime timestamp, List<Double> ecg) {
        this.id = id;
        this.nationalId = nationalId;
        this.heartRate = heartRate;
        this.pulse = pulse;
        this.timestamp = timestamp;
        this.ecg = ecg;
    }

    public ICUSignal(){
}

public ICUSignal(int id, int heartRate, int pulse, LocalDateTime timestamp, List<Doube> ecg){
    Id = id;
    this.heartRate = heartRate;
    this.pulse = pulse;
    this.timestamp = timestamp
            this.ecg = ecg;
}

public ICUSignal(ICUSignalPayload dto){
    Id = dto.
}
}
