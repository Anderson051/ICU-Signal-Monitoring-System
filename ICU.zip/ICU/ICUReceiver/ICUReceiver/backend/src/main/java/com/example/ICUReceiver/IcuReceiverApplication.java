package com.example.ICUReceiver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IcuReceiverApplication {

	public static void main(String[] args) {
		SpringApplication.run(IcuReceiverApplication.class, args);
	}

}
