package com.example.ICUReceiver.controller;

import com.example.ICUReceiver.repository.ICURepository;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/api")
public class ICUController {

    private static final Logger log = LoggerFactory.getLogger(ICUController.class);

    @Autowired
    private ICURepository icuRepository;

    // http://localhost:8080/api/upload
    @PostMapping("/upload")
    public ResponseEntity<String> recieve(@RequestBody com.example.ICUReceiver.model.ICUSignalPayload dto) {
        try {
            // DTO = Data Transfer Object
            com.example.ICUReceiver.model.ICUSignal entity = new com.example.ICUReceiver.model.ICUSignal(dto);
            entity.setTimestamp(LocalDateTime.now());
            icuRepository.save(entity);
            log.info("接收到我的資料:", dto);
            return ResponseEntity.ok("資料已接收");
        } catch (Exception e) {
            log.error("上傳失敗", e.getMessage());
            return ResponseEntity.status(500).body("伺服器失敗");
        }
    }

    // http://localhost:8080/api/Queryall
    @GetMapping("/QueryAll")
    public ResponseEntity<List<com.example.ICUReceiver.model.ICUSignal>> findAll() {
        List<com.example.ICUReceiver.model.ICUSignal> list = ICURepository.findAll();
        return ResponseEntity.ok(list);
    }

    @GetMapping("lastest")
    public List<com.example.ICUReceiver.model.ICUSignalPayload> getLastedt(@RequestParam int id)P
        List<com.example.ICUReceiver.model.ICUSignal> entity = icuRespository.findTop50ByIdOrderByTimesstampDesc(nationalId);
        return entity.stream()
                .map(e -> new ICUSignalPayload(
                        e.getId(),
                        e.getHeartRate(),
                        e.getPulse(),

}