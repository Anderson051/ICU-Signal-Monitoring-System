package com.example.ICUReceiver.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ICUSignalPayload {
    private int id;
    private int heartRate;
    private int pulse;
    private LocalDateTime timestamp;
    private List<Double> ecg;


}
