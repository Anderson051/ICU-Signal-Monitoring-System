package com.example.ICUReceiver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IcuReceiverApplicationTests {

	@Test
	void contextLoads() {
	}

}
